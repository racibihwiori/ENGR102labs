#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 2b.2b
# Date:		29 JANUARY 2019

import numpy as np
x = np.array([1, 3, 7])
y = np.array([23, -5, 10])
time = 13
time2 = 84
time3 = 50
x2 = x[0] + (y[0] - x[0]) / (time2 - time) * (time3 - time)
y2 = x[1] + (y[1] - x[1]) / (time2 - time) * (time3 - time)
z2 = x[2] + (y[2] - x[2]) / (time2 - time) * (time3 - time)
print("The position at time 50 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 51
x2 = x[0] + (y[0] - x[0]) / (time2 - time) * (time3 - time)
y2 = x[1] + (y[1] - x[1]) / (time2 - time) * (time3 - time)
z2 = x[2] + (y[2] - x[2]) / (time2 - time) * (time3 - time)
print("The position at time 51 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 52
x2 = x[0] + (y[0] - x[0]) / (time2 - time) * (time3 - time)
y2 = x[1] + (y[1] - x[1]) / (time2 - time) * (time3 - time)
z2 = x[2] + (y[2] - x[2]) / (time2 - time) * (time3 - time)
print("The position at time 52 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 53
x2 = x[0] + (y[0] - x[0]) / (time2 - time) * (time3 - time)
y2 = x[1] + (y[1] - x[1]) / (time2 - time) * (time3 - time)
z2 = x[2] + (y[2] - x[2]) / (time2 - time) * (time3 - time)
print("The position at time 53 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 54
x2 = x[0] + (y[0] - x[0]) / (time2 - time) * (time3 - time)
y2 = x[1] + (y[1] - x[1]) / (time2 - time) * (time3 - time)
z2 = x[2] + (y[2] - x[2]) / (time2 - time) * (time3 - time)
print("The position at time 54 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")