#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 2b.2c
# Date:		29 JANUARY 2019

import numpy as np
x = np.array([6, 9, 13])
y = np.array([22, 10, 19])
time3 = 20
start = 20
end = 50
x2 = x[0] + (y[0] - x[0]) / (end - start) * (time3 - start)
y2 = x[1] + (y[1] - x[1]) / (end - start) * (time3 - start)
z2 = x[2] + (y[2] - x[2]) / (end - start) * (time3 - start)
print("The position at time 20 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 30

x2 = x[0] + (y[0] - x[0]) / (end - start) * (time3 - start)
y2 = x[1] + (y[1] - x[1]) / (end - start) * (time3 - start)
z2 = x[2] + (y[2] - x[2]) / (end - start) * (time3 - start)
print("The position at time 30 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 40

x2 = x[0] + (y[0] - x[0]) / (end - start) * (time3 - start)
y2 = x[1] + (y[1] - x[1]) / (end - start) * (time3 - start)
z2 = x[2] + (y[2] - x[2]) / (end - start) * (time3 - start)
print("The position at time 40 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 45

x2 = x[0] + (y[0] - x[0]) / (end - start) * (time3 - start)
y2 = x[1] + (y[1] - x[1]) / (end - start) * (time3 - start)
z2 = x[2] + (y[2] - x[2]) / (end - start) * (time3 - start)
print("The position at time 45 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")
time3 = 50

x2 = x[0] + (y[0] - x[0]) / (end - start) * (time3 - start)
y2 = x[1] + (y[1] - x[1]) / (end - start) * (time3 - start)
z2 = x[2] + (y[2] - x[2]) / (end - start) * (time3 - start)
print("The position at time 50 is: ", x2, y2, z2)
print("------------------------------------------------------------------------------------")

