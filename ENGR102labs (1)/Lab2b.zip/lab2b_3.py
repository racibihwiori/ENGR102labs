# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 2b.1
# Date:		29 JANUARY 2019

x = 1
z = 0
z += x
print(z)
x += 1
x += 1
z = 0
z += x
print(z)
y = 10
x = 1
y += x
z = 0
z += y
print (z)
x = 1
x += 1
x += 1
x += 1

y = 10
y += x
x = 1
x += 1
y *= x
z = 0
z += y
print (z)
x = 1
y = 10
x += 1
x += 1
x += 1
y *= x
x = 1
y += x
x += 1
x += 1
y *= x
z = 0
z += y
print(z)
y = 10
x = y
y *= x
y *= x
x = y
y *= x
x = y
y *= x
x = y #1e12
y *= y
z = 0
z += y
print(z)


