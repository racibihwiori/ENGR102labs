# By submitting this assignment, I agree to the following:
#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 2b.1
# Date:		29 JANUARY 2019
import math
print("Rachel Ibihwiori, 527004025, ENGR 102-512")
print("I used to be a competitive dancer on my high school drill team.")

i = 5
r = 20
v = i*r
print(v)
m = 100
s = 21
k = m*s**2
k /= 2
print(k)
vel = 100
kvsc = 1.2
cld = 2.5
d = kvsc*cld
rey = vel/d
print(rey)
sbc = 5.67E-8
temp = 2200**4
e = temp*sbc
print(e)
qi = 100
time = 20
di = 2/time
b = 0.8
prod = qi/(1+b*di*time)**(1/b)
print(prod)

u = 35
ar = 20
umar = u-ar
ar **=2
avle = ar/(u*umar)
print(avle)

nors = 20
coh = 2
shu = math.tan(35)
shst = coh-(nors*shu)
print(shst)

wl = 7.5E-7
dis = 1E-6
dis *=2
ans = wl/dis
scang = math.asin(ans)
print(scang)