#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 3b.1c
# Date:		06 FEBRUARY 2019
import math
qi = float(input('What is the initial rate?'))
t = float(input('What is the time in days?'))
dr = float(input('What is the decline rate?'))
hb = float(input('What is the hyperbolic constant?'))
def arps(a,b,c,d):
    arp = a/((1+b*c*d)**(1/b))
    return arp
ans = arps(qi, hb, dr, t)
print("The production of a well after",t,"days, is:",ans)