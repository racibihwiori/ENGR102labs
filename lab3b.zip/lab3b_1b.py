#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 3b.1b
# Date:		06 FEBRUARY 2019
import math
n = float(input('Enter normal stress'))
theta = float(input('Enter angle of internal friction'))
c = float(input('Enter cohesion'))
def shearstress(x,y,z):
    stress = x + y*(math.tan(z))
    return stress
ans = shearstress(c,n,theta)
print("The shear stress of the object is",ans)