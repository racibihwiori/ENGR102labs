#  “Aggies do not lie, cheat, or steal, or tolerate those who do”
#  “I have not given or received any unauthorized aid on this assignment”
# Name: 		Rachel Ibihwiori
# Section:		ENGR 102-512
# Assignment:	Lab 3b.1d
# Date:		06 FEBRUARY 2019
lmbda = float(input('What is the mean arrival rate?'))
u = float(input('What is the mean service rate?'))
p = lmbda/u #mean customers in service
def mm1(a):
    avlngth = (a**2)/(1-a)
    return avlngth
ans = mm1(p)
print("The mean length in queue is:",ans)